class NotFoundError(Exception):
    pass

class NotURLError(Exception):
    pass

class UserAgentExistsError(Exception):
    pass